rm(list = ls())

library(tidyverse)
library(RColorBrewer)

data <- read.csv("data/main_data_archive.csv")

###################################################################
# Distribution of the knowledge variable

data_know <- data %>%
  select(starts_with("know")) 

table_know <- data_know %>%
  apply(2, table, useNA="always") %>%
  apply(2, prop.table)  %>%
  round(3) 

# Proportion of NA
round(apply(table_know, 2, function(x) mean(is.na(x))), 4)

# label
# 1. never  heard of
# 2. heard of the name
# 3. know what it does roughly
# 4. know what it does in detail

know_response_cat <- c("Never heard of", "Heard of the name", 
                         "Know roughly", "Know details", "NA")

pdf("out/figB3.pdf", width=8, height=7)
par(mar=c(7.1, 7.1, 4.1, 2.1), xpd=TRUE)
barplot(table_know,
        names.arg=c("UN", "WHO", "IMF", "OECD", "G7"),
        beside=F,
        ylab="Proportion",
        col=brewer.pal(5, "Greys"))
legend("bottom",
       legend=know_response_cat,
       fill=brewer.pal(5, "Greys"),
       ncol=5, cex=1, inset=c(0, -0.25), bty="n")
dev.off()

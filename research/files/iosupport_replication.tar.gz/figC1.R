rm(list=ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

###############################################
#Favorability

data <- data %>%
    mutate(IMF_fav_fct = case_when(
        favor_imf < 4 ~ 1,
        favor_imf == 4 ~ 2,
        favor_imf > 4 ~ 3
    ),
    UN_fav_fct = case_when(
        favor_un < 4 ~ 1,
        favor_un == 4 ~ 2,
        favor_un > 4 ~ 3
    ),
    G7_fav_fct = case_when(
        favor_g7 < 4 ~ 1,
        favor_g7 == 4 ~ 2,
        favor_g7 > 4 ~ 3
    )
    )

res_imf_fav <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_fav_fct)),
                             treat=paste0("treat_",
                                          c("IMF")),
                             item=paste0("out_",
                                         c("tax", "gov")),
                             block="block",
                             hetero="IMF_fav_fct")
res_un_fav <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_fav_fct)),
                            treat=paste0("treat_",
                                         c("UN")),
                            item=paste0("out_",
                                        c("tax", "gov")),
                            block="block",
                            hetero="UN_fav_fct")
res_g7_fav <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_fav_fct)),
                            treat=paste0("treat_",
                                         c("G7")),
                            item=paste0("out_",
                                        c("tax", "gov")),
                            block="block",
                            hetero="G7_fav_fct")

res_fav <- as_tibble(rbind(res_imf_fav,
                           res_un_fav,
                           res_g7_fav)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_fav=factor(hetero, levels=c("1", "2", "3"),
                                labels=c("Unfavorable", "Neither", "Favorable"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number()))%>%
    dplyr::filter(treat != "treat_UN")

res_fav$p_bh <- p.adjust(res_fav$p, method = "BH")
res_fav$bh <- ifelse(res_fav$p_bh < 0.05, "Significant", "Not Significant")
res_fav %>%
  dplyr::filter(bh == "Significant")
# G7 treatment is significant for both outcomes
# Imf treatment is significant for gov

fav_g7_gov <- res_fav %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov")
fav_g7_tax <- res_fav %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax")
fav_imf_gov <- res_fav %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov")
fav_imf_tax <- res_fav %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax")

# Number of obs in each subgroup
n_g7_nofav <- fav_g7_gov %>%
    dplyr::filter(perceived_fav == "Unfavorable") %>%
    pull(obs)
n_g7_neutral <- fav_g7_gov %>%
    dplyr::filter(perceived_fav == "Neither") %>%
    pull(obs)
n_g7_fav <- fav_g7_gov %>%
    dplyr::filter(perceived_fav == "Favorable") %>%
    pull(obs)
n_imf_nofav <- fav_imf_gov %>%
    dplyr::filter(perceived_fav == "Unfavorable") %>%
    pull(obs)
n_imf_neutral <- fav_imf_gov %>%
    dplyr::filter(perceived_fav == "Neither") %>%
    pull(obs)
n_imf_fav <- fav_imf_gov %>%
    dplyr::filter(perceived_fav == "Favorable") %>%
    pull(obs)

fav_g7 <- ggplot() +
    geom_point(data = fav_g7_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1), shape = "Government"),
               color = if_else(fav_g7_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = fav_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1)),
                   color = if_else(fav_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = fav_g7_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9), shape = "Policy"),
               color = if_else(fav_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = fav_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9)),
                   color = if_else(fav_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw()+
    scale_x_continuous(breaks = c(-0.8,-0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Unfavorable\n(n= ", n_g7_nofav, ")"),
                                  paste0("Neither\n(n= ", n_g7_neutral, ")"),
                                  paste0("Favorable\n(n= ", n_g7_fav, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.45, y=2.1, label="BH"~symbol("\326")) +
    annotate("text", x=0.5, y=1.9, label="BH"~symbol("\326"))


fav_imf <- ggplot() +
    geom_point(data = fav_imf_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1), shape = "Government"),
               color = if_else(fav_imf_gov$p > 0.05, "darkgrey", "black"),size = 2) +
    geom_linerange(data = fav_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1)),
                   color = if_else(fav_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = fav_imf_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9), shape = "Policy"),
               color = if_else(fav_imf_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = fav_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9)),
                   color = if_else(fav_imf_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8,-0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6,0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Unfavorable\n(n= ", n_imf_nofav, ")"),
                                  paste0("Neither\n(n= ", n_imf_neutral, ")"),
                                  paste0("Favorable\n(n= ", n_imf_fav, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.7, y=2.8, label="BH"~symbol("\326"))


combined_plot <- fav_g7 + fav_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot

ggsave("out/figC1.pdf", width = 8, height = 4)

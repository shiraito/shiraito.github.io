rm(list = ls())

## sample
data <- read.csv("data/main_data_archive.csv")

male.hist <- hist(data$age[data$gender == 1L]
                , breaks = seq(from = 0, to = 105, by = 5), plot = FALSE)
female.hist <- hist(data$age[data$gender == 2L]
                , breaks = seq(from = 0, to = 105, by = 5), plot = FALSE)

pdf("out/figB4a.pdf", width = 4.5, height = 5.5)
par(mfrow = c(1, 2), mar = c(2, 3, 4, 2))
barplot(male.hist$density, horiz = TRUE
      , names.arg = paste(seq(0, 100, 5), c(rep("-", 20), "<="), c(seq(4, 100, 5), ""))
      , main = paste("Male\nn =", sum(data$gender == 1L)), axes = FALSE
      , cex.names = .7, las = 2)
barplot(female.hist$density, horiz = TRUE
      , names.arg = paste(seq(0, 100, 5), c(rep("-", 20), "<="), c(seq(4, 100, 5), ""))
      , main = paste("Female\nn =", sum(data$gender == 2L)), axes = FALSE
      , cex.names = .7, las = 2)
dev.off()

## population
pop.data <- read.csv("data/population_agegender.csv")[, -c(1:6)]
pop.data <- subset(pop.data, subset = pop.data[, "人口区分"] == "日本人人口")

pop.male.hist <- pop.data[pop.data[, "性別"] == "男", "X7.1.2023"][2:22]
pop.male.hist <- pop.male.hist / sum(pop.male.hist)

pop.female.hist <- pop.data[pop.data[, "性別"] == "女", "X7.1.2023"][2:22]
pop.female.hist <- pop.female.hist / sum(pop.female.hist)


pdf("figB4b.pdf", width = 4.5, height = 5.5)
par(mfrow = c(1, 2), mar = c(2, 3, 4, 2))
barplot(pop.male.hist, horiz = TRUE
      , names.arg = paste(seq(0, 100, 5), c(rep("-", 20), "<="), c(seq(4, 100, 5), ""))
      , main = paste("Male"), axes = FALSE
      , cex.names = .7, las = 2)
barplot(pop.female.hist, horiz = TRUE
      , names.arg = paste(seq(0, 100, 5), c(rep("-", 20), "<="), c(seq(4, 100, 5), ""))
      , main = paste("Female"), axes = FALSE
      , cex.names = .7, las = 2)
dev.off()

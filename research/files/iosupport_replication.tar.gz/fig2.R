rm(list=ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

#######################################################
#expertise
data <- data %>%
    mutate(IMF_expertise_fct = case_when(
        IO_expertise_3 < 4 ~ 1,
        IO_expertise_3 == 4 ~ 2,
        IO_expertise_3 > 4 ~ 3
    ),
    UN_expertise_fct = case_when(
        IO_expertise_1 < 4 ~ 1,
        IO_expertise_1 == 4 ~ 2,
        IO_expertise_1 > 4 ~ 3
    ),
    G7_expertise_fct = case_when(
        IO_expertise_5 < 4 ~ 1,
        IO_expertise_5 == 4 ~ 2,
        IO_expertise_5 > 4 ~ 3
    ))

res_imf_expertise <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_expertise_fct)),
                                   treat=paste0("treat_",
                                                c("IMF")),
                                   item=paste0("out_",
                                               c("tax", "gov")),
                                   block="block",
                                   hetero="IMF_expertise_fct")
res_un_expertise <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_expertise_fct)),
                                  treat=paste0("treat_",
                                               c("UN")),
                                  item=paste0("out_",
                                              c("tax", "gov")),
                                  block="block",
                                  hetero="UN_expertise_fct")
res_g7_expertise <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_expertise_fct)),
                                  treat=paste0("treat_",
                                               c("G7")),
                                  item=paste0("out_",
                                              c("tax", "gov")),
                                  block="block",
                                  hetero="G7_expertise_fct")

res_expertise <- as_tibble(rbind(res_imf_expertise,
                                 res_un_expertise,
                                 res_g7_expertise)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_expertise=factor(hetero, levels=c("1", "2", "3"),
                                      labels=c("No Expertise",
                                               "Neither",
                                               "Expertise"))) %>%
    arrange(treat, item, hetero) %>%
    arrange(desc(row_number())) %>%
    dplyr::filter(treat != "treat_UN")


res_expertise$p_bh <- p.adjust(res_expertise$p, method = "BH")
res_expertise$bh <- ifelse(res_expertise$p_bh < 0.05, "Significant", "Not Significant")
res_expertise %>%
  dplyr::filter(bh == "Significant")
# None of the effect estimates is significant

exp_g7_gov <- res_expertise %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov")
exp_g7_tax <- res_expertise %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax")
exp_imf_gov <- res_expertise %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov")
exp_imf_tax <- res_expertise %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax")

# Number of obs in each subgroup
n_g7_noexpertise <- exp_g7_gov %>%
    dplyr::filter(perceived_expertise == "No Expertise") %>%
    pull(obs)
n_g7_neutral <- exp_g7_gov %>%
    dplyr::filter(perceived_expertise == "Neither") %>%
    pull(obs)
n_g7_expertise <- exp_g7_gov %>%
    dplyr::filter(perceived_expertise == "Expertise") %>%
    pull(obs)
n_imf_noexpertise <- exp_imf_gov %>%
    dplyr::filter(perceived_expertise == "No Expertise") %>%
    pull(obs)
n_imf_neutral <- exp_imf_gov %>%
    dplyr::filter(perceived_expertise == "Neither") %>%
    pull(obs)
n_imf_expertise <- exp_imf_gov %>%
    dplyr::filter(perceived_expertise == "Expertise") %>%
    pull(obs)

exp_g7 <- ggplot() +
    geom_point(data = exp_g7_gov,
               aes(x = point, y = c(3.1, 2.1, 1.1), shape = "Government"),
               color = if_else(exp_g7_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = exp_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(3.1, 2.1, 1.1)),
                   color = if_else(exp_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = exp_g7_tax,
               aes(x = point, y = c(2.9, 1.9, 0.9), shape = "Policy"),
               color = if_else(exp_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = exp_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(2.9, 1.9, 0.9)),
                   color = if_else(exp_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("No Expertise\n(n= ", n_g7_noexpertise, ")"),
                                  paste0("Neither\n(n= ", n_g7_neutral, ")"),
                                  paste0("Expertise\n(n= ", n_g7_expertise, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold"),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10))

exp_imf <- ggplot() +
    geom_point(data = exp_imf_gov,
               aes(x = point, y = c(3.1, 2.1, 1.1), shape = "Government"),
               color = if_else(exp_imf_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = exp_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(3.1, 2.1, 1.1)),
                   color = if_else(exp_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = exp_imf_tax,
               aes(x = point, y = c(2.9, 1.9, 0.9), shape = "Policy"),
               color = if_else(exp_imf_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = exp_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(2.9, 1.9, 0.9)),
                   color = if_else(exp_imf_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("No Expertise\n(n= ", n_imf_noexpertise, ")"),
                                  paste0("Neither\n(n= ",n_imf_neutral, ")"),
                                  paste0("Expertise\n(n= ", n_imf_expertise, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold"),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10))


combined_plot <- exp_g7 + exp_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot
ggsave("out/fig2_2.pdf", combined_plot, width = 8, height = 4)


# Distribution
data_expertise <- data %>%
  select("expertise_g7", "expertise_imf") %>%
    pivot_longer(cols = c("expertise_g7", "expertise_imf"),
                 names_to = "expertise_name",
                 values_to = "expertise")

labels <- as_labeller(c("expertise_g7" = "G7", "expertise_imf" = "IMF"))

p0=ggplot(data_expertise, aes(x = expertise)) +
  geom_histogram(binwidth = 1,
                 color = "white") +
  scale_x_continuous(breaks = seq(0,10,by=1),
                     labels = seq(0,10,by=1)) +
  facet_wrap(~expertise_name, labeller = labels)+
  theme_bw() +
  scale_y_continuous(limits = c(0,3000))+
  labs(x="Perceived Levels of Expertise", y="Respondents Count")
ggsave("out/fig2_1.pdf", p0, width = 8, height = 4)

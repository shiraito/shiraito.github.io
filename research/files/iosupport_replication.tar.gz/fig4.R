rm(list=ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

##################################################
#Japan neutral

data <- data %>%
    mutate(IMF_jp_neutral_fct = case_when(
        neutral_japan_imf < 4 ~ 1,
        neutral_japan_imf == 4 ~ 2,
        neutral_japan_imf > 4 ~ 3
    ),
    UN_jp_neutral_fct = case_when(
        neutral_japan_un < 4 ~ 1,
        neutral_japan_un  == 4 ~ 2,
        neutral_japan_un > 4 ~ 3
    ),
    G7_jp_neutral_fct = case_when(
        neutral_japan_g7 < 4 ~ 1,
        neutral_japan_g7 == 4 ~ 2,
        neutral_japan_g7 > 4 ~ 3
    )
    )
res_imf_jp_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_jp_neutral_fct)),
                                    treat=paste0("treat_",
                                                 c("IMF")),
                                    item=paste0("out_",
                                                c("tax", "gov")),
                                    block="block",
                                    hetero="IMF_jp_neutral_fct")
res_un_jp_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_jp_neutral_fct)),
                                   treat=paste0("treat_",
                                                c("UN")),
                                   item=paste0("out_",
                                               c("tax", "gov")),
                                   block="block",
                                   hetero="UN_jp_neutral_fct")
res_g7_jp_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_jp_neutral_fct)),
                                   treat=paste0("treat_",
                                                c("G7")),
                                   item=paste0("out_",
                                               c("tax", "gov")),
                                   block="block",
                                   hetero="G7_jp_neutral_fct")

res_jp_neutral <- as_tibble(rbind(res_imf_jp_neutral,
                                  res_un_jp_neutral,
                                  res_g7_jp_neutral)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_jp_neutral=factor(hetero, levels=c("1", "2", "3"),
                                       labels=c("Japan's Interest Reflected",
                                                "Neither",
                                                "Not Reflected"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number())) %>%
    dplyr::filter(treat != "treat_UN")

res_jp_neutral$p_bh <- p.adjust(res_jp_neutral$p, method = "BH")
res_jp_neutral$bh <- ifelse(res_jp_neutral$p_bh < 0.05, "Significant", "Not Significant")
res_jp_neutral %>%
  dplyr::filter(bh == "Significant") %>%
  select(treat, item)
# G7 treatment on both outcomes is significant
# IMF on gov is significant

jp_g7_gov <- res_jp_neutral %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov") %>%
    arrange(desc(hetero))
jp_g7_tax <- res_jp_neutral %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax") %>%
    arrange(desc(hetero))
jp_imf_gov <- res_jp_neutral %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov") %>%
    arrange(desc(hetero))
jp_imf_tax <- res_jp_neutral %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax") %>%
    arrange(desc(hetero))

  # Number of obs in each subgroup
n_g7_nojp <- jp_g7_gov %>%
    dplyr::filter(perceived_jp_neutral == "Not Reflected") %>%
    pull(obs)
n_g7_neutral <- jp_g7_gov %>%
    dplyr::filter(perceived_jp_neutral == "Neither") %>%
    pull(obs)
n_g7_jp <- jp_g7_gov %>%
    dplyr::filter(perceived_jp_neutral == "Japan's Interest Reflected") %>%
    pull(obs)
n_imf_nojp <- jp_imf_gov %>%
    dplyr::filter(perceived_jp_neutral == "Not Reflected") %>%
    pull(obs)
n_imf_neutral <- jp_imf_gov %>%
    dplyr::filter(perceived_jp_neutral == "Neither") %>%
    pull(obs)
n_imf_jp <- jp_imf_gov %>%
    dplyr::filter(perceived_jp_neutral == "Japan's Interest Reflected") %>%
    pull(obs)

jp_g7 <- ggplot() +
    geom_point(data = jp_g7_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1), shape = "Government"),
               color = if_else(jp_g7_gov$p > 0.05, "darkgrey", "black"),size = 2) +
    geom_linerange(data = jp_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1)),
                   color = if_else(jp_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = jp_g7_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9), shape = "Policy"),
               color = if_else(jp_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = jp_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9)),
                   color = if_else(jp_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw()+
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Not Reflected\n(n= ", n_g7_nojp, ")"),
                                  paste0("Neither\n(n= ", n_g7_neutral, ")"),
                                  paste0("Japan's Interest\nReflected\n(n= ", n_g7_jp, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.63, y=3.1, label="BH"~symbol("\326")) +
    annotate("text", x=0.67, y=2.9, label="BH"~symbol("\326"))


jp_imf <- ggplot() +
    geom_point(data = jp_imf_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1), shape = "Government"),
               color = if_else(jp_imf_gov$p > 0.05, "darkgrey", "black"),size = 2) +
    geom_linerange(data = jp_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1)),
                   color = if_else(jp_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = jp_imf_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9), shape = "Policy"),
               color = if_else(jp_imf_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = jp_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9)),
                   color = if_else(jp_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Not Reflected\n(n= ", n_imf_nojp, ")"),
                                  paste0("Neither\n(n= ", n_imf_neutral, ")"),
                                  paste0("Japan's Interest\nReflected\n(n= ", n_imf_jp, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.7, y=3.1, label="BH"~symbol("\326"))


combined_plot <- jp_g7 + jp_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot
ggsave("out/fig4_2.pdf", combined_plot, width = 8, height = 4)

data_japan <- data %>%
  select("neutral_japan_g7", "neutral_japan_imf") %>%
  pivot_longer(cols = c("neutral_japan_g7", "neutral_japan_imf"),
               names_to = "japan_name",
               values_to = "japan")

labels <- as_labeller(c("neutral_japan_g7" = "G7", "neutral_japan_imf" = "IMF"))


p0=ggplot(data_japan, aes(x = japan)) +
  geom_histogram(binwidth = 1,
                 color = "white") +
  scale_x_continuous(breaks = seq(0,10,by=1),
                     labels = seq(0,10,by=1)) +
  facet_wrap(~japan_name, labeller = labels) +
  theme_bw() +
  labs(x="Perceived Levels of Reflection of Japan's Interests", y="Respondents Count")
ggsave("out/fig4_1.pdf", p0, width = 8, height = 4)

README for replication files;
----------------------------
INITIAL DEPOSIT DATE: 7/29/2025
THIS VERSION: 7/29/2025
-----------------------------
ARTICLE: "IO Endorsements, Perceived Alignment, and Public Support for Unpopular Policies"
AUTHORS: Saki Kuzushima, Itsuki Umeyama, Kenneth Mori McElwain, and Yuki Shiraito
-----------------------------
Replication code and data needed to reproduce results presented in-text and in the Supplementary Information provided for the study. 

Please report any errors to Yuki Shiraito; current contact info: shiraito@umich.edu
-----------------------------
FILE LIST:

data/main_data_archive.csv -- original survey data
data/population_agegender.csv -- population distribution of age and gender as of July 1, 2023. Source: e-Stat, a Japanese government service (https://www.e-stat.go.jp/stat-search/files?tclass=000001007604&cycle=7&year=20230)

main.R -- R script that produces all figures in the main text and the supplementary information

functions.R -- functions for estimation

code/*.R -- R scripts that are run in main.R. Each file can be run separately as well.

out/ -- Directory that contains output files. File names are self-explanatory about which file corresponds to which figure/table

-----------------------------
PACKAGE VERSIONS:

R - 4.5.1
tidyverse - 2.0.0
  dplyr     1.1.4
  readr     2.1.5
  forcats   1.0.0
  stringr   1.5.1
  ggplot2   3.5.0
  tibble    3.2.1
  lubridate 1.9.3
  tidyr     1.3.1
  purrr     1.0.2     
texreg - 1.39.4
estimatr - 1.0.6
patchwork - 1.2.0
ggpubr - 0.6.0
RColorBrewer - 1.1-3

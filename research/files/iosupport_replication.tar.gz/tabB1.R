rm(list = ls())

library(tidyverse)
library(xtable)

data <- read.csv("data/main_data_archive.csv")

##################################
tabB1.obj <- matrix(data = character(0), ncol = 4)
colnames(tabB1.obj) <- c("Variable", "Levels", "n", "%")

## gender
tabB1.obj <- rbind(tabB1.obj
                 , cbind(rep("Gender", 4)
                       , c("Male", "Female", "Other", "NA")
                       , table(data$gender)
                       , round(prop.table(table(data$gender)) * 100
                             , digits = 1)
                         )
                   )

## age
data <- data %>%
    mutate(age_dist = case_when(age >= 19 & age < 30 ~ 1,
                                age >= 30 & age < 40 ~ 2,
                                age >= 40 & age < 50 ~ 3,
                                age >= 50 & age < 60 ~ 4,
                                age >= 60  ~ 5))
tabB1.obj <- rbind(tabB1.obj
                 , cbind(rep("Age", 5)
                       , c("19--29", "30--39", "40--49", "50--59", "60--70")
                       , table(data$age_dist)
                       , round(prop.table(table(data$age_dist)) * 100
                               , digits = 1)
                         )
                   )

## education and income
data <- data %>%
    mutate(edu_dist = case_when(education == 6 | education == 7 ~ 1,
                                education == NA_integer_ ~ 2,
                                TRUE ~ 0),
           income_dist = case_when(income == 1 | income == 2 ~ 1,
                                   income == 3 | income == 4 ~ 2,
                                   income == 5 | income == 6 ~ 3,
                                   income == 7 | income == 8 ~ 4,
                                   income == 9 | income == 10 ~ 5,
                                   income == 11 | income == 12 ~ 6,
                                   income == 13 ~ 7))
tabB1.obj <- rbind(tabB1.obj
                 , cbind(rep("Education", 2)
                       , c("College", "Not college")
                       , table(data$edu_dist)[2:1]
                       , round(prop.table(table(data$edu_dist)[2:1]) * 100
                               , digits = 1)
                         )
                   )
tabB1.obj <- rbind(tabB1.obj
                 , cbind(rep("Income (yen)", 7)
                       , c("< 2M", "2M--4M", "4M--6M", "6M--8M", "8M--10M", "10M--12M", "> 12M")
                       , table(data$income_dist)
                       , round(prop.table(table(data$income_dist)) * 100
                             , digits = 1)
                         )
                   )

## partisanship
data <- data %>%
    mutate(party_fct = case_when(
        partyID == 1 | partyID == 4 ~ "Gov",
        partyID == 10 ~ "Independent",
        partyID == 2 |partyID == 3 | partyID == 5 | partyID == 6 |
        partyID == 7 | partyID == 8 |  partyID == 9  ~ "Opposition",
        TRUE ~ NA_character_
    ),
    party_fct = factor(party_fct, levels=c("Gov", "Independent", "Opposition"))
    )
tabB1.obj <- rbind(tabB1.obj
                 , cbind(rep("Partisanship", 3)
                       , c("Gov", "Independent", "Opposition")
                       , table(data$party_fct)
                       , round(prop.table(table(data$party_fct)) * 100
                             , digits = 1)
                         )
                   )
print(xtable(tabB1.obj)
    , include.rownames = FALSE
    , file = "out/tabB1.tex")

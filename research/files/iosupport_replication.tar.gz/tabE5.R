rm(list=ls())

library(tidyverse)
library(xtable)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

########################################################
#partisanship

data <- data %>%
    mutate(party_fct = case_when(
        partyID == 1 | partyID == 4 ~ "Gov",
        partyID == 10 ~ "Independent",
        partyID == 2 |partyID == 3 | partyID == 5 | partyID == 6 |
            partyID == 7 | partyID == 8 |  partyID == 9  ~ "Opposition",
        TRUE ~ NA_character_
    ),
    party_fct = factor(party_fct, levels=c("Gov", "Independent", "Opposition"))
    )

res_party <- effect_hetero(data=data %>% dplyr::filter(!is.na(party_fct)),
                           treat=paste0("treat_",
                                        c("IMF", "UN", "G7")),
                           item=paste0("out_",
                                       c("tax", "gov")),
                           block="block",
                           hetero="party_fct")

res_party <- res_party %>%
    as_tibble() %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(partisanship=hetero) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number())) %>%
    dplyr::filter(treat != "treat_UN")
res_party$p_bh <- p.adjust(res_party$p, method = "BH")
res_party$bh <- ifelse(res_party$p_bh < 0.05, "Significant", "Not Significant")
res_party %>%
  dplyr::filter(bh == "Significant") %>%
  select(hetero, treat, item)

print(xtable(res_party[, c("partisanship", "item", "treat", "point", "se"
                             , "p", "p_bh")])
      , file = "out/tabE5.tex")

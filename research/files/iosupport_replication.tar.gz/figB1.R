rm(list = ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

data <- read.csv("data/main_data_archive.csv")

data <- data %>%
    mutate(treat=case_when(treat=="G7"~"G7",
                           treat=="IMF"~"IMF",
                           treat=="UN"~"UN",
                           treat=="control"~"Control"))

###################################################################
## Histgram of outcome variable: Gov support

summary_stats_gov <- data %>%
    group_by(treat) %>%
    summarise(
        mean_val = mean(out_gov, na.rm = TRUE),
        sd_val = sd(out_gov, na.rm = TRUE)
    )

labels <- as_labeller(c("G7" = "Endorsement from G7",
                        "IMF" = "Endorsement from IMF",
                        "UN" = "Endorsement from UN",
                        "Control" = "Control"))

ggplot(data, aes(x = out_gov)) +
   geom_histogram(binwidth = 1,color = "white")+
    geom_vline(data = summary_stats_gov, aes(xintercept = mean_val), color = "red", linetype = "dashed") +
    geom_text(data = summary_stats_gov,
              aes(x = mean_val, y = 800,
                  label = paste0("Mean = ", round(mean_val, 2), "\nSD = ", round(sd_val, 2))),
              vjust = 2, hjust = -0.1, size = 3.2, color = "red") +
   scale_x_continuous(breaks = seq(0,10,by=1),labels = seq(0,10,by=1))+
   facet_wrap(~treat, labeller = labels)+
   theme_bw() +
   labs(x="Levels of Support for the Current Government",
        y="Number of Respondents")
ggsave("out/figB1.pdf", width = 8, height = 5)

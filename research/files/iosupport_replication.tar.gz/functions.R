# functions to estimate ate

diffmean_helper <- function(data, treatment, item){
  if (length(treatment)!= nrow(data) & length(treatment)!=1){
    stop("treatment must be the name of the column for treatment")
  }
  treat_filter <- data[,treatment] == 1
  control_filter <- data[,treatment] == 0

  treat <- subset(data, treat_filter)
  control <- subset(data, control_filter)
  point <- mean(treat[,item,drop=T], na.rm=T) -
            mean(control[,item,drop=T], na.rm=T)
  n1 <- sum(!is.na(treat[,item]))
  n0 <- sum(!is.na(control[,item]))
  se <- sqrt(var(treat[,item], na.rm=T)/n1 + var(control[,item], na.rm=T)/n0)

  #upper <- point + qnorm(0.975)*se
  #lower <- point + qnorm(0.025)*se
  return(c(point, se))
}

diffmean_simple <- function(data, treatment, item){

  out <- diffmean_helper(data, treatment, item)
  point <- out[1]; se <- out[2]
  upper <- point + qnorm(0.975)*se
  lower <- point + qnorm(0.025)*se
  p <- 2*(1-pnorm(abs(point/se)))
  return(c(lower, point, upper, p, se))
}

diffmean_block <- function(data, treatment, item, block="block"){
  data_ls <- split(data, data[,block])
  group_est <- as.data.frame(t(sapply(data_ls, diffmean_helper, treatment, item)))
  colnames(group_est) <- c("ate", "se")
  block_n <- as.numeric(table(data[,block,drop=T])) ## of obs in each block
  group_est$n <- block_n
  N <- sum(group_est$n)

  # weighted sum for point estimate
  point <- sum(group_est$ate * group_est$n / N, na.rm=T)
  # weighted sum for se
  se <- sqrt(sum(group_est$se^2 * (group_est$n/N)^2, na.rm=T))

  upper <- point + qnorm(0.975)*se
  lower <- point + qnorm(0.025)*se
  p <- 2*(1-pnorm(abs(point/se)))

  #add # of respondents
  obs <- (sum(group_est$n))

  out <- c(lower, point, upper, p, se, obs)
  names(out) <- c("lower", "point", "upper", "p", "se", "obs")
  return(out)

}

balance_block <- function(data, treatment, item, block){
  # balance test for each block

  data_ls <- split(data, data[,block])
  group_est <- as.data.frame(t(sapply(data_ls, diffmean_helper, treatment, item)))
  colnames(group_est) <- c("ate", "se")
  block_n <- as.numeric(table(data[,block,drop=T])) ## of obs in each block
  group_est$n <- block_n
  N <- sum(group_est$n)
  group_est$lower <- group_est$ate- qnorm(0.975)*group_est$se
  group_est$upper <- group_est$ate+ qnorm(0.975)*group_est$se
  group_est$p <- 0
  for (r in 1:nrow(group_est)){
    group_est$p[r] <- 2*(1-pnorm(abs(group_est$ate[r]/group_est$se[r])))
  }

  return(group_est)

}

diffmean_block_hetero <- function(data,
                                  treatment,
                                  item,
                                  block="block",
                                  hetero=NULL){
  if (is.null(hetero)){
    out <- diffmean_block(data, treatment, item, block)
  } else {
    data_ls <- split(data, data[,hetero])
    out <- sapply(data_ls, diffmean_block,
                  treatment=treatment, item=item, block=block)
  }
  return(out)
}

effect_hetero <- function(data,
                          item,
                          treat,
                          block,
                          hetero){

  if (sum(is.na(data[,hetero]))){
    stop("hetero cannot have missing values")
  }

  if (is.factor(data[,hetero,drop=T])){
    hetero_levels <- levels(data[,hetero,drop=T])
  } else if (is.character(data[,hetero,drop=T])){
    hetero_levels <- unique(data[,hetero,drop=T])
  } else if (is.numeric(data[,hetero,drop=T])){
    hetero_levels <- sort(unique(data[,hetero,drop=T]))
  } else {
    stop("hetero must be a factor, character, or numeric")
  }

  res <- expand.grid(hetero=hetero_levels,
                     item=item,
                     treat=treat)
  #add # of respondents
  res$obs <- res$se <- res$p <- res$upper <- res$point <- res$lower <-  NA

  for (itm in item){
    for (trt in treat){
      res_sub <- diffmean_block_hetero(data=data,
                                       treat=trt,
                                       item=itm,
                                       block=block,
                                       hetero=hetero)
      res[res$item==itm & res$treat==trt, 4:9] <- t(res_sub)
    }
  }
  return(res)
}


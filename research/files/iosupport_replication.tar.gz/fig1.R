rm(list=ls())

library(tidyverse)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

##########################################################
#ATE

res_ate <- expand.grid(outcome=c("tax", "gov"),
                       treat=c("IMF", "UN", "G7"))
res_ate$obs <- res_ate$se <- res_ate$p <- res_ate$upper <- res_ate$point <- res_ate$lower<- NA


for (treat in c("IMF", "UN", "G7")){
    for (outcome in c("tax", "gov")){
        temp <- diffmean_block(data=data,
                               treat=paste0("treat_", treat),
                               item=paste0("out_", outcome),
                               block="block")

        res_ate[res_ate$treat == treat & res_ate$outcome == outcome, 3:8] <- t(temp)
    }
} #ignore obs

ate_gov <- res_ate %>%
    dplyr::filter(outcome == "gov") %>%
    mutate(outcome = "Government")
ate_tax <- res_ate %>%
    dplyr::filter(outcome == "tax") %>%
    mutate(outcome = "Policy")

# Multiple testing check
ate <- rbind(ate_gov, ate_tax)
ate$p_bh <- p.adjust(ate$p, method = "BH")
ate$bh <- ifelse(ate$p_bh < 0.05, "Significant", "Not Significant")
ate %>%
  dplyr::filter(bh == "Significant")
# G7 treatments on both outcomes are the only significant ones

n_g7 <- sum(!is.na(data$treat_G7))
n_imf <- sum(!is.na(data$treat_IMF))
n_un <- sum(!is.na(data$treat_UN))

ggplot() +
    geom_point(data = ate_gov,
               aes(x = point, y = c(2.1, 1.1, 3.1), shape = "Government"),
               color = if_else(ate_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = ate_gov,
                   aes(xmin = lower, xmax = upper, y = c(2.1, 1.1, 3.1)),
                   color = if_else(ate_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = ate_tax,
               aes(x = point, y = c(1.9, 0.9, 2.9), shape = "Policy"),
               color = if_else(ate_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = ate_tax,
                   aes(xmin = lower, xmax = upper, y = c(1.9, 0.9, 2.9)),
                   color = if_else(ate_tax$p > 0.05, "darkgrey", "black"),lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support for")) +
    xlab("Average Treatment Effect") +
    ylab("") +
    theme_bw() +
    scale_x_continuous(breaks = seq(-0.4, 0.4, 0.1),
                       limits = c(-0.4, 0.4)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c("UN", "IMF", "G7"),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 12, face = "bold"),
          legend.position = "bottom") +
    annotate("text", x=0.35, y=3.1, label="BH"~symbol("\326")) +
    annotate("text", x=0.38, y=2.9, label="BH"~symbol("\326"))

ggsave("out/fig1.pdf", width=4, height=4)

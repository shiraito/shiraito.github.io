rm(list=ls())

library(tidyverse)
library(estimatr)
library(texreg)
source("functions.R")

data <- read.csv("data/main_data_archive.csv")

################################################################################
data_lin <- data %>%
  select(block,
         treat_IMF,
         treat_G7,
         treat_UN,
         out_tax,
         out_gov, 
         contains("indiv_economy"),
         contains("social_economy"),
         contains("tax_self"),
         contains("tax_compared"),
         income)

out_lin_tax_imf <- lm_lin(
  out_tax ~ treat_IMF,
  covariates = ~ indiv_economy_now + 
    social_economy_now + 
    tax_self + tax_compared + 
    income + block,
  data = data_lin
)

out_lin_tax_g7 <- lm_lin(
  out_tax ~ treat_G7,
  covariates = ~ indiv_economy_now + 
    social_economy_now + 
    tax_self + tax_compared + 
    income + block,
  data = data_lin
)
out_lin_tax_un <- lm_lin(
  out_tax ~ treat_UN,
  covariates = ~ indiv_economy_now + 
    social_economy_now + 
    tax_self + tax_compared + 
    income + block,
  data = data_lin
)

tex_lin_tax <- texreg(list(out_lin_tax_imf, out_lin_tax_g7, out_lin_tax_un),
  custom.model.names = c("IMF", "G7", "UN"),
  custom.note = "",
  stars = numeric(0),
  single.row = TRUE)
write.table(tex_lin_tax, file = "out/tabD1.tex",
            sep = "&", row.names = FALSE, col.names = FALSE,
            quote = FALSE, eol = "\\\\\n")


out_lin_gov_imf <- lm_lin(
  out_gov ~ treat_IMF,
  covariates = ~ indiv_economy_now + 
    social_economy_now + 
    tax_self + tax_compared + 
    income + block,
  data = data_lin
)

out_lin_gov_g7 <- lm_lin(
  out_gov ~ treat_G7,
  covariates = ~ indiv_economy_now + 
    social_economy_now + 
    tax_self + tax_compared + 
    income + block,
  data = data_lin
)
out_lin_gov_un <- lm_lin(
  out_gov ~ treat_UN,
  covariates = ~ indiv_economy_now + 
    social_economy_now + 
    tax_self + tax_compared + 
    income + block,
  data = data_lin
)

tex_lin_gov <- texreg(list(out_lin_gov_imf, out_lin_gov_g7, out_lin_gov_un),
  custom.model.names = c("IMF", "G7", "UN"),
  stars = numeric(0),
  single.row = TRUE)
write.table(tex_lin_gov, file = "out/tabD2.tex",
            sep = "&", row.names = FALSE, col.names = FALSE,
            quote = FALSE, eol = "\\\\\n")

## multiple testing correction
p.vec <- c(out_lin_tax_imf$p.value,
           out_lin_tax_g7$p.value,
           out_lin_tax_un$p.value,
           out_lin_gov_imf$p.value,
           out_lin_gov_g7$p.value,
           out_lin_gov_un$p.value)
q.values <- round(p.adjust(p.vec, method = "BH"), 3)
names(q.values) <- paste(rep(c("tax", "gov"), each = length(q.values) / 2)
                       , rep(rep(c("imf", "g7", "un")
                               , each = length(out_lin_tax_imf$p.value))
                           , times = 2)
                       , names(q.values)
                       , sep = ":")
print(q.values < .05)

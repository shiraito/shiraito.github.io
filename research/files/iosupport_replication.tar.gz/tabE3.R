rm(list=ls())

library(tidyverse)
library(xtable)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

################################################
#IO Neutral

data <- data %>%
    mutate(IMF_neutral_fct = case_when(
        neutral_states_imf < 4 ~ 1,
        neutral_states_imf == 4 ~ 2,
        neutral_states_imf > 4 ~ 3
    ),
    UN_neutral_fct = case_when(
        neutral_states_un < 4 ~ 1,
        neutral_states_un == 4 ~ 2,
        neutral_states_un > 4 ~ 3
    ),
    G7_neutral_fct = case_when(
        neutral_states_g7 < 4 ~ 1,
        neutral_states_g7 == 4 ~ 2,
        neutral_states_g7 > 4 ~ 3
    )
    )

# Neutral from memebr states' interests
res_imf_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_neutral_fct)),
                                 treat=paste0("treat_",
                                              c("IMF")),
                                 item=paste0("out_",
                                             c("tax", "gov")),
                                 block="block",
                                 hetero="IMF_neutral_fct")
res_un_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_neutral_fct)),
                                treat=paste0("treat_",
                                             c("UN")),
                                item=paste0("out_",
                                            c("tax", "gov")),
                                block="block",
                                hetero="UN_neutral_fct")
res_g7_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_neutral_fct)),
                                treat=paste0("treat_",
                                             c("G7")),
                                item=paste0("out_",
                                            c("tax", "gov")),
                                block="block",
                                hetero="G7_neutral_fct")

res_neutral <- as_tibble(rbind(res_imf_neutral,
                               res_un_neutral,
                               res_g7_neutral)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_neutral=factor(hetero, levels=c("1", "2", "3"),
                                    labels=c("Not Neutral", "Neither", "Neutral"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number()))%>%
    dplyr::filter(treat != "treat_UN")

res_neutral$p_bh <- p.adjust(res_neutral$p, method = "BH")
res_neutral$bh <- ifelse(res_neutral$p_bh < 0.05, "Significant", "Not Significant")
res_neutral %>%
  dplyr::filter(bh == "Significant")
# G7 treatment among "Not-neutral" is significant for both outcomes

print(xtable(res_neutral[, c("perceived_neutral", "item", "treat", "point", "se"
                             , "p", "p_bh")])
      , file = "out/tabE3.tex")

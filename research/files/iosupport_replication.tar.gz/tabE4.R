rm(list=ls())

library(tidyverse)
library(xtable)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

##################################################
#Japan neutral

data <- data %>%
    mutate(IMF_jp_neutral_fct = case_when(
        neutral_japan_imf < 4 ~ 1,
        neutral_japan_imf == 4 ~ 2,
        neutral_japan_imf > 4 ~ 3
    ),
    UN_jp_neutral_fct = case_when(
        neutral_japan_un < 4 ~ 1,
        neutral_japan_un  == 4 ~ 2,
        neutral_japan_un > 4 ~ 3
    ),
    G7_jp_neutral_fct = case_when(
        neutral_japan_g7 < 4 ~ 1,
        neutral_japan_g7 == 4 ~ 2,
        neutral_japan_g7 > 4 ~ 3
    )
    )
res_imf_jp_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_jp_neutral_fct)),
                                    treat=paste0("treat_",
                                                 c("IMF")),
                                    item=paste0("out_",
                                                c("tax", "gov")),
                                    block="block",
                                    hetero="IMF_jp_neutral_fct")
res_un_jp_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_jp_neutral_fct)),
                                   treat=paste0("treat_",
                                                c("UN")),
                                   item=paste0("out_",
                                               c("tax", "gov")),
                                   block="block",
                                   hetero="UN_jp_neutral_fct")
res_g7_jp_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_jp_neutral_fct)),
                                   treat=paste0("treat_",
                                                c("G7")),
                                   item=paste0("out_",
                                               c("tax", "gov")),
                                   block="block",
                                   hetero="G7_jp_neutral_fct")

res_jp_neutral <- as_tibble(rbind(res_imf_jp_neutral,
                                  res_un_jp_neutral,
                                  res_g7_jp_neutral)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_jp_neutral=factor(hetero, levels=c("1", "2", "3"),
                                       labels=c("Japan's Interest Reflected",
                                                "Neither",
                                                "Not Reflected"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number())) %>%
    dplyr::filter(treat != "treat_UN")

res_jp_neutral$p_bh <- p.adjust(res_jp_neutral$p, method = "BH")
res_jp_neutral$bh <- ifelse(res_jp_neutral$p_bh < 0.05, "Significant", "Not Significant")
res_jp_neutral %>%
  dplyr::filter(bh == "Significant") %>%
  select(treat, item)
# G7 treatment on both outcomes is significant

print(xtable(res_jp_neutral[, c("perceived_jp_neutral", "item", "treat", "point", "se"
                             , "p", "p_bh")])
      , file = "out/tabE4.tex")

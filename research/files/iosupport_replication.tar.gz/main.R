##
## "IO Endorsements, Perceived Alignment, and Public Support for Unpopular Policies"
## main file for replication
##
rm(list = ls())

## check the working directory
if (!("main.R" %in% list.files())) {
    stop("Make sure to set the working directory to the location of the main file!")
}

## check the required packages
if (!(all(c("tidyverse", "xtable", "texreg", "estimatr", "RColorBrewer"
            , "patchwork", "ggpubr") %in% library()$results[, "Package"]))) {
    stop("Install required packages: tidyverse, xtable, texreg, estimatr, RColorBrewer, patchwork, ggpubr")
}

##
## results in main text
##
source("fig1.R")
source("fig2.R")
source("fig3.R")
source("fig4.R")
source("fig5.R")


##
## results in SI
##
## ## Figures and Tables in SI B
source("figB1.R")
source("figB2.R")
source("figB3.R")
source("tabB1.R")
source("figB4.R")
source("tabB2.R")

## ## Tables in SI C
source("figC1.R")
source("figC2.R")
source("figC3.R")

## ## Tables in SI D
source("tabD1-2.R")

## ## Tables in SI E
source("tabE1.R")
source("tabE2.R")
source("tabE3.R")
source("tabE4.R")
source("tabE5.R")


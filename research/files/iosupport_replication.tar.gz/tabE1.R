rm(list=ls())

library(tidyverse)
library(xtable)
source("functions.R")

data <- read.csv("data/main_data_archive.csv")

##########################################################
#ATE

res_ate <- expand.grid(outcome=c("tax", "gov"),
                       treat=c("IMF", "UN", "G7"))
res_ate$obs <- res_ate$se <- res_ate$p <- res_ate$upper <- res_ate$point <- res_ate$lower<- NA


for (treat in c("IMF", "UN", "G7")){
    for (outcome in c("tax", "gov")){
        temp <- diffmean_block(data=data,
                               treat=paste0("treat_", treat),
                               item=paste0("out_", outcome),
                               block="block")

        res_ate[res_ate$treat == treat & res_ate$outcome == outcome, 3:8] <- t(temp)
    }
} #ignore obs

ate_gov <- res_ate %>%
    dplyr::filter(outcome == "gov") %>%
    mutate(outcome = "Government")
ate_tax <- res_ate %>%
    dplyr::filter(outcome == "tax") %>%
    mutate(outcome = "Policy")

# Multiple testing check
ate <- rbind(ate_gov, ate_tax)
ate$p_bh <- p.adjust(ate$p, method = "BH")
ate$bh <- ifelse(ate$p_bh < 0.05, "Significant", "Not Significant")
ate %>%
  dplyr::filter(bh == "Significant")
# G7 treatments on both outcomes are the only significant ones

print(xtable(ate[, c("outcome", "treat", "point", "se", "p", "p_bh")])
    , file = "out/tabE1.tex")

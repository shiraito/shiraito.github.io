rm(list=ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

################################################
#IO Neutral
data <- data %>%
    mutate(IMF_neutral_fct = case_when(
        neutral_states_imf < 4 ~ 1,
        neutral_states_imf == 4 ~ 2,
        neutral_states_imf > 4 ~ 3
    ),
    UN_neutral_fct = case_when(
        neutral_states_un < 4 ~ 1,
        neutral_states_un == 4 ~ 2,
        neutral_states_un > 4 ~ 3
    ),
    G7_neutral_fct = case_when(
        neutral_states_g7 < 4 ~ 1,
        neutral_states_g7 == 4 ~ 2,
        neutral_states_g7 > 4 ~ 3
    )
    )

# Neutral from memebr states' interests
res_imf_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_neutral_fct)),
                                 treat=paste0("treat_",
                                              c("IMF")),
                                 item=paste0("out_",
                                             c("tax", "gov")),
                                 block="block",
                                 hetero="IMF_neutral_fct")
res_un_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_neutral_fct)),
                                treat=paste0("treat_",
                                             c("UN")),
                                item=paste0("out_",
                                            c("tax", "gov")),
                                block="block",
                                hetero="UN_neutral_fct")
res_g7_neutral <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_neutral_fct)),
                                treat=paste0("treat_",
                                             c("G7")),
                                item=paste0("out_",
                                            c("tax", "gov")),
                                block="block",
                                hetero="G7_neutral_fct")

res_neutral <- as_tibble(rbind(res_imf_neutral,
                               res_un_neutral,
                               res_g7_neutral)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_neutral=factor(hetero, levels=c("1", "2", "3"),
                                    labels=c("Not Neutral", "Neither", "Neutral"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number()))%>%
    dplyr::filter(treat != "treat_UN")

res_neutral$p_bh <- p.adjust(res_neutral$p, method = "BH")
res_neutral$bh <- ifelse(res_neutral$p_bh < 0.05, "Significant", "Not Significant")
res_neutral %>%
  dplyr::filter(bh == "Significant")
# G7 treatment among "Not-neutral" is significant for both outcomes

neut_g7_gov <- res_neutral %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov")
neut_g7_tax <- res_neutral %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax")
neut_imf_gov <- res_neutral %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov")
neut_imf_tax <- res_neutral %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax")

# Number of obs in each subgroup
n_g7_noneutral <- neut_g7_gov %>%
    dplyr::filter(perceived_neutral == "Not Neutral") %>%
    pull(obs)
n_g7_neither <- neut_g7_gov %>%
    dplyr::filter(perceived_neutral == "Neither") %>%
    pull(obs)
n_g7_neutral <- neut_g7_gov %>%
    dplyr::filter(perceived_neutral == "Neutral") %>%
    pull(obs)
n_imf_noneutral <- neut_imf_gov %>%
    dplyr::filter(perceived_neutral == "Not Neutral") %>%
    pull(obs)
n_imf_neither <- neut_imf_gov %>%
    dplyr::filter(perceived_neutral == "Neither") %>%
    pull(obs)
n_imf_neutral <- neut_imf_gov %>%
    dplyr::filter(perceived_neutral == "Neutral") %>%
    pull(obs)

neut_g7 <- ggplot() +
    geom_point(data = neut_g7_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1), shape = "Government"),
               color = if_else(neut_g7_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = neut_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1)),
                   color = if_else(neut_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = neut_g7_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9), shape = "Policy"),
               color = if_else(neut_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = neut_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9)),
                   color = if_else(neut_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw()+
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Subject to\nStates' Interests\n(n= ", n_g7_noneutral, ")"),
                                  paste0("Neither\n(n= ", n_g7_neither, ")"),
                                  paste0("Independent from\nStates' Interests\n(n= ", n_g7_neutral, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.53, y=1.1, label="BH"~symbol("\326")) +
    annotate("text", x=0.63, y=0.9, label="BH"~symbol("\326"))

neut_imf <- ggplot() +
    geom_point(data = neut_imf_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1), shape = "Government"),
               color = if_else(neut_imf_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = neut_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1)),
                   color = if_else(neut_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = neut_imf_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9), shape = "Policy"),
               color = if_else(neut_imf_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = neut_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9)),
                   color = if_else(neut_imf_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6,0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Subject to\nStates' Interests\n(n= ", n_imf_noneutral, ")"),
                                  paste0("Neither\n(n= ", n_imf_neither, ")"),
                                  paste0("Independent from\nStates' Interests\n(n= ", n_imf_neutral, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10))


combined_plot <- neut_g7 + neut_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot
ggsave("out/fig3_2.pdf", combined_plot, width = 8, height = 4)

# Distribution
data_neutral <- data %>%
  select("neutral_states_g7", "neutral_states_imf") %>%
  pivot_longer(cols = c("neutral_states_g7", "neutral_states_imf"),
               names_to = "neutral_name",
               values_to = "neutral")

labels <- as_labeller(c("neutral_states_g7" = "G7", "neutral_states_imf" = "IMF"))

p0=ggplot(data_neutral, aes(x = neutral)) +
  geom_histogram(binwidth = 1,
                 color = "white") +
  scale_x_continuous(breaks = seq(0,10,by=1),
                     labels = seq(0,10,by=1)) +
  facet_wrap(~neutral_name, labeller = labels)+
  theme_bw() +
  scale_y_continuous(limits = c(0,3000))+
  labs(x="Perceived Levels of Neutrality", y="Respondents Count")
ggsave("out/fig3_1.pdf", p0, width = 8, height = 4)

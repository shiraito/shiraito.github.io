rm(list=ls())

library(tidyverse)
library(xtable)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

#######################################################
#expertise
data <- data %>%
    mutate(IMF_expertise_fct = case_when(
        IO_expertise_3 < 4 ~ 1,
        IO_expertise_3 == 4 ~ 2,
        IO_expertise_3 > 4 ~ 3
    ),
    UN_expertise_fct = case_when(
        IO_expertise_1 < 4 ~ 1,
        IO_expertise_1 == 4 ~ 2,
        IO_expertise_1 > 4 ~ 3
    ),
    G7_expertise_fct = case_when(
        IO_expertise_5 < 4 ~ 1,
        IO_expertise_5 == 4 ~ 2,
        IO_expertise_5 > 4 ~ 3
    ))

res_imf_expertise <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_expertise_fct)),
                                   treat=paste0("treat_",
                                                c("IMF")),
                                   item=paste0("out_",
                                               c("tax", "gov")),
                                   block="block",
                                   hetero="IMF_expertise_fct")
res_un_expertise <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_expertise_fct)),
                                  treat=paste0("treat_",
                                               c("UN")),
                                  item=paste0("out_",
                                              c("tax", "gov")),
                                  block="block",
                                  hetero="UN_expertise_fct")
res_g7_expertise <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_expertise_fct)),
                                  treat=paste0("treat_",
                                               c("G7")),
                                  item=paste0("out_",
                                              c("tax", "gov")),
                                  block="block",
                                  hetero="G7_expertise_fct")

res_expertise <- as_tibble(rbind(res_imf_expertise,
                                 res_un_expertise,
                                 res_g7_expertise)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_expertise=factor(hetero, levels=c("1", "2", "3"),
                                      labels=c("No Expertise",
                                               "Neither",
                                               "Expertise"))) %>%
    arrange(treat, item, hetero) %>%
    arrange(desc(row_number())) %>%
    dplyr::filter(treat != "treat_UN")


res_expertise$p_bh <- p.adjust(res_expertise$p, method = "BH")
res_expertise$bh <- ifelse(res_expertise$p_bh < 0.05, "Significant", "Not Significant")
res_expertise %>%
  dplyr::filter(bh == "Significant")
# None of the effect estimates is significant

## table of estimates for R&R
print(xtable(res_expertise[, c("perceived_expertise", "item", "treat", "point", "se"
                             , "p", "p_bh")])
    , file = "out/tabE2.tex")

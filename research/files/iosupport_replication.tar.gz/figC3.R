rm(list=ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

###############################################
# IO knowledge

data <- data %>%
    mutate(IMF_kn_fct = case_when(
        IO_knowledge_3 == 1 ~ 1,
        IO_knowledge_3 == 2 ~ 2,
        IO_knowledge_3 == 3 ~ 3,
        IO_knowledge_3 == 4 ~ 4
    ),
    G7_kn_fct = case_when(
        IO_knowledge_5 == 1 ~ 1,
        IO_knowledge_5 == 2 ~ 2,
        IO_knowledge_5 == 3 ~ 3,
        IO_knowledge_5 == 4 ~ 4
    ),
    UN_kn_fct = case_when(
        IO_knowledge_1 == 1 ~ 1,
        IO_knowledge_1 == 2 ~ 2,
        IO_knowledge_1 == 3 ~ 3,
        IO_knowledge_1 == 4 ~ 4
    )
    )

res_imf_kn <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_kn_fct)),
                                 treat=paste0("treat_",
                                              c("IMF")),
                                 item=paste0("out_",
                                             c("tax", "gov")),
                                 block="block",
                                 hetero="IMF_kn_fct")
res_un_kn <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_kn_fct)),
                                treat=paste0("treat_",
                                             c("UN")),
                                item=paste0("out_",
                                            c("tax", "gov")),
                                block="block",
                                hetero="UN_kn_fct")
res_g7_kn <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_kn_fct)),
                                treat=paste0("treat_",
                                             c("G7")),
                                item=paste0("out_",
                                            c("tax", "gov")),
                                block="block",
                                hetero="G7_kn_fct")

res_kn <- as_tibble(rbind(res_imf_kn,
                               res_un_kn,
                               res_g7_kn)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(kn=factor(hetero, levels=c("1", "2", "3", "4"),
                                    labels=c("Never Heard", "Heard its Name", "Know Roughly", "Know in Details"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number()))

res_kn$p_bh <- p.adjust(res_kn$p, method = "BH")
res_kn$bh <- ifelse(res_kn$p_bh < 0.05, "Significant", "Not Significant")
res_kn %>%
    dplyr::filter(bh == "Significant") #out_gov, G7, know in details


kn_g7_gov <- res_kn %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov")
kn_g7_tax <- res_kn %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax")
kn_imf_gov <- res_kn %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov")
kn_imf_tax <- res_kn %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax")

# Number of obs in each subgroup

n_g7_never <- kn_g7_gov %>%
    dplyr::filter(kn == "Never Heard") %>%
    pull(obs)
n_g7_heard <- kn_g7_gov %>%
    dplyr::filter(kn == "Heard its Name") %>%
    pull(obs)
n_g7_roughly <- kn_g7_gov %>%
    dplyr::filter(kn == "Know Roughly") %>%
    pull(obs)
n_g7_details <- kn_g7_gov %>%
    dplyr::filter(kn == "Know in Details") %>%
    pull(obs)
n_imf_never <- kn_imf_gov %>%
    dplyr::filter(kn == "Never Heard") %>%
    pull(obs)
n_imf_heard <- kn_imf_gov %>%
    dplyr::filter(kn == "Heard its Name") %>%
    pull(obs)
n_imf_roughly <- kn_imf_gov %>%
    dplyr::filter(kn == "Know Roughly") %>%
    pull(obs)
n_imf_details <- kn_imf_gov %>%
    dplyr::filter(kn == "Know in Details") %>%
    pull(obs)



kn_g7 <- ggplot() +
    geom_point(data = kn_g7_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1, 4.1), shape = "Government"),
               color = if_else(kn_g7_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = kn_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1, 4.1)),
                   color = if_else(kn_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = kn_g7_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9, 3.9), shape = "Policy"),
               color = if_else(kn_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = kn_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9, 3.9)),
                   color = if_else(kn_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw()+
    scale_x_continuous(breaks = c(-1.0, -.5, 0, .5, 1.0),
                       limits = c(-1.1, 1.1)) +
    scale_y_continuous(breaks = c(1, 2, 3, 4),
                       labels = c(paste0("Never Heard\n(n= ", n_g7_never, ")"),
                                  paste0("Heard its Name\n(n= ", n_g7_heard, ")"),
                                  paste0("Know Roughly\n(n= ", n_g7_roughly, ")"),
                                  paste0("Know in Details\n(n= ", n_g7_details, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 4.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.63, y=4.2, label="BH"~symbol("\326"))

kn_imf <- ggplot() +
    geom_point(data = kn_imf_gov,
               aes(x = point, y = c(1.1, 2.1, 3.1, 4.1), shape = "Government"),
               color = if_else(kn_imf_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = kn_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(1.1, 2.1, 3.1, 4.1)),
                   color = if_else(kn_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = kn_imf_tax,
               aes(x = point, y = c(0.9, 1.9, 2.9, 3.9), shape = "Policy"),
               color = if_else(kn_imf_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = kn_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(0.9, 1.9, 2.9, 3.9)),
                   color = if_else(kn_imf_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw()+
    scale_x_continuous(breaks = c(-1.0, -.5, 0, .5, 1.0),
                       limits = c(-1.1, 1.1)) +
    scale_y_continuous(breaks = c(1, 2, 3, 4),
                       labels = c(paste0("Never Heard\n(n= ", n_imf_never, ")"),
                                  paste0("Heard its Name\n(n= ", n_imf_heard, ")"),
                                  paste0("Know Roughly\n(n= ", n_imf_roughly, ")"),
                                  paste0("Know in Details\n(n= ", n_imf_details, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 4.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10))


combined_plot <- kn_g7 + kn_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot

ggsave("out/figC3.pdf", width = 8, height = 4)

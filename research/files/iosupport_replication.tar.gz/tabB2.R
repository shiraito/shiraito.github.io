rm(list = ls())

library(tidyverse)
library(xtable)

d <- read.csv("data/main_data_archive.csv")

##############################
variables_list <- c("IO_expertise_1", "IO_expertise_3", "IO_expertise_5", "IO_neutral_1", "IO_neutral_3", "IO_neutral_5", "japan_neutral_1", "japan_neutral_3", "japan_neutral_5", "favor_un", "favor_imf", "favor_g7")

summary_stats <- map_dfr(variables_list, function(var){
    x <- d[[var]]
    tibble(
        variable = var,
        mean = mean(x, na.rm = TRUE),
        sd = sd(x, na.rm = TRUE),
        min = min(x, na.rm = TRUE),
        max = max(x, na.rm = TRUE)
    )
})

variable_labels <- c(
    IO_expertise_1 = "UN Expertise",
    IO_expertise_3 = "IMF Expertise",
    IO_expertise_5 = "G7 Expertise",
    IO_neutral_1   = "UN Neutrality",
    IO_neutral_3   = "IMF Neutrality",
    IO_neutral_5   = "G7 Neutrality",
    japan_neutral_1 = "Reflection of Japanese Gov (UN)",
    japan_neutral_3 = "Reflection of Japanese Gov (IMF)",
    japan_neutral_5 = "Reflection of Japanese Gov (G7)",
    favor_un = "UN Favorability",
    favor_imf = "IMF Favorability",
    favor_g7 = "G7 Favorability"
)

summary_stats <- summary_stats %>%
    mutate(variable = recode(variable, !!!variable_labels))

latex_code <- print(xtable(summary_stats, digits = 2), include.rownames = FALSE, print.results = FALSE)

writeLines(latex_code, "out/tabB2.tex")

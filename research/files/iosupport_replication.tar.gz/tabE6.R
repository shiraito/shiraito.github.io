rm(list=ls())

library(tidyverse)
library(xtable)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

#######################################################
#Favorability

data <- data %>%
    mutate(IMF_fav_fct = case_when(
        favor_imf < 4 ~ 1,
        favor_imf == 4 ~ 2,
        favor_imf > 4 ~ 3
    ),
    UN_fav_fct = case_when(
        favor_un < 4 ~ 1,
        favor_un == 4 ~ 2,
        favor_un > 4 ~ 3
    ),
    G7_fav_fct = case_when(
        favor_g7 < 4 ~ 1,
        favor_g7 == 4 ~ 2,
        favor_g7 > 4 ~ 3
    )
    )

res_imf_fav <- effect_hetero(data=data %>% dplyr::filter(!is.na(IMF_fav_fct)),
                             treat=paste0("treat_",
                                          c("IMF")),
                             item=paste0("out_",
                                         c("tax", "gov")),
                             block="block",
                             hetero="IMF_fav_fct")
res_un_fav <- effect_hetero(data=data %>% dplyr::filter(!is.na(UN_fav_fct)),
                            treat=paste0("treat_",
                                         c("UN")),
                            item=paste0("out_",
                                        c("tax", "gov")),
                            block="block",
                            hetero="UN_fav_fct")
res_g7_fav <- effect_hetero(data=data %>% dplyr::filter(!is.na(G7_fav_fct)),
                            treat=paste0("treat_",
                                         c("G7")),
                            item=paste0("out_",
                                        c("tax", "gov")),
                            block="block",
                            hetero="G7_fav_fct")

res_fav <- as_tibble(rbind(res_imf_fav,
                           res_un_fav,
                           res_g7_fav)) %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(perceived_fav=factor(hetero, levels=c("1", "2", "3"),
                                labels=c("Unfavorable", "Neither", "Favorable"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number()))%>%
    dplyr::filter(treat != "treat_UN")

res_fav$p_bh <- p.adjust(res_fav$p, method = "BH")
res_fav$bh <- ifelse(res_fav$p_bh < 0.05, "Significant", "Not Significant")
res_fav %>%
  dplyr::filter(bh == "Significant")
# G7 treatment is significant for both outcomes
# Imf treatment is significant for gov

## table of estimates for R&R
print(xtable(res_fav[, c("perceived_fav", "item", "treat", "point", "se", "p", "p_bh")])
      , file = "out/tabE6.tex")

rm(list=ls())

library(tidyverse)
library(ggpubr)
library(patchwork)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

###############################################
# deficit

data <- data %>%
    mutate(deficit_fct = case_when(
        deficit < 4 ~ 1,
        deficit == 4 ~ 2,
        deficit > 4 ~ 3))

res_deficit <- effect_hetero(data=data %>% dplyr::filter(!is.na(deficit_fct)),
                             treat=paste0("treat_",
                                          c("G7", "IMF", "UN")),
                             item=paste0("out_",
                                         c("tax", "gov")),
                             block="block",
                             hetero="deficit_fct")

res_deficit <- res_deficit %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(df=factor(hetero, levels=c("1", "2", "3"),
                          labels=c("No Worries", "Neither", "Worried"))) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number()))

res_deficit$p_bh <- p.adjust(res_deficit$p, method = "BH")
res_deficit$bh <- ifelse(res_deficit$p_bh < 0.05, "Significant", "Not Significant")
res_deficit %>%
    dplyr::filter(bh == "Significant") %>%
    select(hetero, treat, item)

df_g7_gov <- res_deficit %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov")
df_g7_tax <- res_deficit %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax")
df_imf_gov <- res_deficit %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov")
df_imf_tax <- res_deficit %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax")

# Number of obs in each subgroup
n_g7_noworries <- df_g7_gov %>%
    dplyr::filter(df == "No Worries") %>%
    pull(obs)
n_g7_neither <- df_g7_gov %>%
    dplyr::filter(df == "Neither") %>%
    pull(obs)
n_g7_worried <- df_g7_gov %>%
    dplyr::filter(df == "Worried") %>%
    pull(obs)
n_imf_noworries <- df_imf_gov %>%
    dplyr::filter(df == "No Worries") %>%
    pull(obs)
n_imf_neither <- df_imf_gov %>%
    dplyr::filter(df == "Neither") %>%
    pull(obs)
n_imf_worried <- df_imf_gov %>%
    dplyr::filter(df == "Worried") %>%
    pull(obs)

df_imf <- ggplot() +
    geom_point(data = df_imf_gov,
               aes(x = point, y = c(3.1, 2.1, 1.1), shape = "Government"),
               color = if_else(df_imf_gov$p > 0.05, "darkgrey", "black"),size = 2) +
    geom_linerange(data = df_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(3.1, 2.1, 1.1)),
                   color = if_else(df_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = df_imf_tax,
               aes(x = point, y = c(2.9, 1.9, 0.9), shape = "Policy"),
               color = if_else(df_imf_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = df_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(2.9, 1.9, 0.9)),
                   color = if_else(df_imf_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Worried about \nJapan's Deficit \n(n= ", n_imf_worried, ")"),
                                  paste0("Neither\n(n= ", n_imf_neither, ")"),
                                  paste0("Not Worried \nabout Japan's Deficit\n(n= ", n_imf_noworries, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10))

df_g7 <- ggplot() +
    geom_point(data = df_g7_gov,
               aes(x = point, y = c(3.1, 2.1, 1.1), shape = "Government"),
               color = if_else(df_g7_gov$p > 0.05, "darkgrey", "black"),size = 2) +
    geom_linerange(data = df_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(3.1, 2.1, 1.1)),
                   color = if_else(df_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = df_g7_tax,
               aes(x = point, y = c(2.9, 1.9, 0.9), shape = "Policy"),
               color = if_else(df_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = df_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(2.9, 1.9, 0.9)),
                   color = if_else(df_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Support For")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.9, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 0.9),
                       limits = c(-0.9, 0.9)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Worried about \nJapan's Deficit\n(n= ", n_g7_worried, ")"),
                                  paste0("Neither\n(n= ", n_g7_neither, ")"),
                                  paste0("Not Worried about Japan's Deficit\n(n= ", n_g7_noworries, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10))


combined_plot <- df_g7 + df_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot

ggsave("out/figC2.pdf", width=8, height=4)

rm(list=ls())

library(tidyverse)

source("functions.R")

data <- read.csv("data/main_data_archive.csv")

########################################################
#partisanship

data <- data %>%
    mutate(party_fct = case_when(
        partyID == 1 | partyID == 4 ~ "Gov",
        partyID == 10 ~ "Independent",
        partyID == 2 |partyID == 3 | partyID == 5 | partyID == 6 |
            partyID == 7 | partyID == 8 |  partyID == 9  ~ "Opposition",
        TRUE ~ NA_character_
    ),
    party_fct = factor(party_fct, levels=c("Gov", "Independent", "Opposition"))
    )

res_party <- effect_hetero(data=data %>% dplyr::filter(!is.na(party_fct)),
                           treat=paste0("treat_",
                                        c("IMF", "UN", "G7")),
                           item=paste0("out_",
                                       c("tax", "gov")),
                           block="block",
                           hetero="party_fct")

res_party <- res_party %>%
    as_tibble() %>%
    mutate(model=paste0(item, "_", treat, "_h", hetero)) %>%
    mutate(partisanship=hetero) %>%
    arrange(treat, item, desc(hetero)) %>%
    arrange(desc(row_number())) %>%
    dplyr::filter(treat != "treat_UN")
res_party$p_bh <- p.adjust(res_party$p, method = "BH")
res_party$bh <- ifelse(res_party$p_bh < 0.05, "Significant", "Not Significant")
res_party %>%
  dplyr::filter(bh == "Significant") %>%
  select(hetero, treat, item)

party_g7_gov <- res_party %>%
    dplyr::filter(treat == "treat_G7" & item == "out_gov")
party_g7_tax <- res_party %>%
    dplyr::filter(treat == "treat_G7" & item == "out_tax")
party_imf_gov <- res_party %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_gov")
party_imf_tax <- res_party %>%
    dplyr::filter(treat == "treat_IMF" & item == "out_tax")

# Number of obs in each subgroup
n_g7_gov <- party_g7_gov %>%
    dplyr::filter(partisanship == "Gov") %>%
    pull(obs)
n_g7_ind <- party_g7_gov %>%
    dplyr::filter(partisanship == "Independent") %>%
    pull(obs)
n_g7_opp <- party_g7_gov %>%
    dplyr::filter(partisanship == "Opposition") %>%
    pull(obs)
n_imf_gov <- party_imf_gov %>%
    dplyr::filter(partisanship == "Gov") %>%
    pull(obs)
n_imf_ind <- party_imf_gov %>%
    dplyr::filter(partisanship == "Independent") %>%
    pull(obs)
n_imf_opp <- party_imf_gov %>%
    dplyr::filter(partisanship == "Opposition") %>%
    pull(obs)

party_g7 <- ggplot() +
    geom_point(data = party_g7_gov,
               aes(x = point, y = c(3.1, 2.1, 1.1), shape = "Government"),
               color = if_else(party_g7_gov$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = party_g7_gov,
                   aes(xmin = lower, xmax = upper, y = c(3.1, 2.1, 1.1)),
                   color = if_else(party_g7_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = party_g7_tax,
               aes(x = point, y = c(2.9, 1.9, 0.9), shape = "Policy"),
               color = if_else(party_g7_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = party_g7_tax,
                   aes(xmin = lower, xmax = upper, y = c(2.9, 1.9, 0.9)),
                   color = if_else(party_g7_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Partisanship")) +
    labs(title = "G7", x = "Average Treatment Effect", y = NULL) +
    theme_bw()+
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Opposition\n(n= ", n_g7_opp, ")"),
                                  paste0("Independent\n(n= ", n_g7_ind, ")"),
                                  paste0("Government\n(n= ", n_g7_gov, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.73, y=3.1, label="BH"~symbol("\326")) +
    annotate("text", x=0.7, y=2.8, label="BH"~symbol("\326"))


party_imf <- ggplot() +
    geom_point(data = party_imf_gov,
               aes(x = point, y = c(3.1, 2.1, 1.1), shape = "Government"),
               color = if_else(party_imf_gov$p > 0.05, "darkgrey", "black"),size = 2) +
    geom_linerange(data = party_imf_gov,
                   aes(xmin = lower, xmax = upper, y = c(3.1, 2.1, 1.1)),
                   color = if_else(party_imf_gov$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    geom_point(data = party_imf_tax,
               aes(x = point, y = c(2.9, 1.9, 0.9), shape = "Policy"),
               color = if_else(party_imf_tax$p > 0.05, "darkgrey", "black"), size = 2) +
    geom_linerange(data = party_imf_tax,
                   aes(xmin = lower, xmax = upper, y = c(2.9, 1.9, 0.9)),
                   color = if_else(party_imf_tax$p > 0.05, "darkgrey", "black"), lwd = 0.6) +
    scale_shape_manual(values = c(Government = 15, Policy = 17)) +
    geom_vline(xintercept = 0, linetype = "dashed") +
    guides(shape = guide_legend(title = "Partisanship")) +
    labs(title = "IMF", x = "Average Treatment Effect", y = NULL) +
    theme_bw() +
    scale_x_continuous(breaks = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                       limits = c(-0.8, 0.8)) +
    scale_y_continuous(breaks = c(1, 2, 3),
                       labels = c(paste0("Opposition \n(n= ", n_imf_opp, ")"),
                                  paste0("Independent\n(n= ", n_imf_ind, ")"),
                                  paste0("Government \n(n= ", n_imf_gov, ")")),
                       expand = c(0, 0),
                       limits = c(0.5, 3.5),
                       position = "left",
                       name = "") +
    theme(axis.text.y = element_text(size = 8, face = "bold", hjust = 1),
          plot.title = element_text(hjust = 0.5),
          axis.title.x = element_text(size = 10)) +
    annotate("text", x=0.73, y=3.1, label="BH"~symbol("\326")) +
    annotate("text", x=0.73, y=2.8, label="BH"~symbol("\326"))


combined_plot <- party_g7 + party_imf +  plot_layout(ncol = 2, guides = "collect") &
    theme(legend.position = "bottom")
combined_plot

ggsave("out/fig5.pdf", width = 8, height = 4)

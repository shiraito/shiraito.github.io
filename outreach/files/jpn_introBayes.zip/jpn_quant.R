## data
poll <- read.csv("polls16.csv")
poll$date <- as.Date(poll$date)
outcome <- read.csv("outcomes16.csv")


## plot Michigan polls
poll.mi <- subset(poll, subset = location == "MI")
poll.mi <- poll.mi[order(poll.mi$samplesize), ]
poll.mi <- subset(poll.mi, subset = !duplicated(date))
mi.se <- sqrt((poll.mi$trump.pct / 100) * (1 - (poll.mi$trump.pct / 100)) /
              poll.mi$samplesize)
mi.ci <- cbind(poll.mi$trump.pct + 100 * qnorm(.025) * mi.se,
               poll.mi$trump.pct + 100 * qnorm(.975) * mi.se)
par(mar = c(4, 4, 3, 0))
plot(poll.mi$date, poll.mi$trump.pct,
     ylim = c(min(mi.ci), max(mi.ci)),
     xlab = "Date", ylab = "Trump's vote share (%)", pch = 19)
abline(h = outcome$trump.actual[outcome$state == "MI"], lty = 2)
for (i in 1:nrow(mi.ci)) {
    lines(x = rep(poll.mi$date[i], 2), y = mi.ci[i, ])
}


## posterior distribution
prior.alpha <- 1
prior.beta <- 1

trump.count <- tapply(poll$trump.count, poll$location, sum)
sample.size <- tapply(poll$samplesize, poll$location, sum)

post.alpha <- trump.count + prior.alpha
post.beta <- sample.size - trump.count + prior.beta

post.mean <- post.alpha / (post.alpha + post.beta)
vote.actual <- outcome$trump.actual[order(outcome$state)] / 100

par(mar = c(4, 4, 0, 0))
plot(vote.actual, post.mean,
     xlab="Actual Vote Share", ylab="Posterior Mean",
     xlim=c(0,.85),ylim=c(0,.85),
     pch=16,col=adjustcolor("black",alpha=.3))
abline(a=0,b=1,lty=2,col="dark grey",lwd=2)
abline(h = .5, lty = 3)
abline(v = .5, lty = 4)
for (i in 1:length(vote.actual)){
    lines(rep(vote.actual[i], 2),
          qbeta(c(.025, .975), post.alpha[i], post.beta[i]))
}


## focus on battleground states
vote.actual.battle <- vote.actual[vote.actual <.53 & vote.actual >.47]
post.mean.battle <- post.mean[vote.actual <.53 & vote.actual >.47]
post.alpha.battle <- post.alpha[vote.actual <.53 & vote.actual >.47]
post.beta.battle <- post.beta[vote.actual <.53 & vote.actual >.47]
par(mar = c(4, 4, 0, 0))
plot(vote.actual.battle, post.mean.battle,
     xlab="Actual Vote Share", ylab="Posterior Mean",
     xlim=c(.47,.53), ylim=c(.45,.55),
     pch = 16, col=adjustcolor("black",alpha=.3))
abline(a=0, b=1, lty=2, col="dark grey", lwd=2)
abline(h = .5, lty = 3)
abline(v = .5, lty = 4)
for (i in 1:length(vote.actual.battle)){
    text(vote.actual.battle[i], post.mean.battle[i], names(post.mean.battle)[i],
         adj = c(.5, 0), col = adjustcolor("black",alpha=.3))
}
for (i in 1:length(vote.actual.battle)){
    lines(rep(vote.actual.battle[i], 2),
          qbeta(c(.025, .975), post.alpha.battle[i], post.beta.battle[i]))
}


## ## install vdemdata package from GitHub if not installed
## library(remotes)
## install_github("vdeminstitute/vdemdata")


## V-Dem data and extract gender-related indices
library(vdemdata)
tmp.df <- find_var("gender, women, female")
tmp.df <- subset(tmp.df, subset = vartype == "C" & !is_party & !is.na(histmerged) & !is.na(question_number))
indname <- unique(tmp.df$tag)
print(c(tmp.df$question))

rm(tmp.df)


## plot raw indices
vdem.latest <- subset(vdem, subset = year == max(year))
gen.index <- scale(subset(vdem.latest, select = indname))
country.name <- vdem.latest$country_name[complete.cases(gen.index)]
gen.index <- gen.index[complete.cases(gen.index), ]
obj4matplot <- subset(gen.index, subset = country.name %in% c("Japan",
                                                              "Iceland",
                                                              "United States of America",
                                                              "Philippines",
                                                              "China",
                                                              "North Korea"))
rownames(obj4matplot) <- country.name[country.name %in% c("Japan",
                                                          "Iceland",
                                                          "United States of America",
                                                          "Philippines",
                                                          "China",
                                                          "North Korea")]
obj4matplot <- obj4matplot[c("Japan",
                             "Iceland",
                             "United States of America",
                             "Philippines",
                             "China",
                             "North Korea"), ]

par(mar= c(4, 4, 0, 0))
matplot(obj4matplot, axes = FALSE,
        xlab = "Country", ylab = "Normalized Index",
        pch = 7:(6 + ncol(obj4matplot)), col = adjustcolor("black",alpha=.5))
axis(2)
axis(1, labels = c("Japan",
                   "Iceland",
                   "United\nStates",
                   "Philippines",
                   "China",
                   "North\nKorea"),
     at = 1:6, lwd = 0, cex.axis = .7)


## Bayesian factor analysis
library(MCMCpack, quietly = TRUE)
out.factor <- MCMCfactanal(gen.index,
                           factors = 1L, store.scores = TRUE,
                           lambda.constraints = list(v2lgfemleg = list(1, "+")),
                           burnin = 10000L, mcmc = 20000L, thin = 10L)
out.factor <- out.factor[, grep("phi", colnames(out.factor))]
colnames(out.factor) <- country.name
summary4plot <- summary(out.factor)$quantiles[c("Japan",
                                                "Iceland",
                                                "United States of America",
                                                "Philippines",
                                                "China",
                                                "North Korea"),
                                              c("2.5%", "50%", "97.5%")]
par(mar = c(4, 4, 0, 0))
plot(summary4plot[, "50%"], ylim = c(min(summary4plot), max(summary4plot)),
     xlab = "Country", ylab = "Score based on gender-related indices", axes = FALSE, pch = 3)
axis(2)
axis(1, labels = c("Japan",
                   "Iceland",
                   "United\nStates",
                   "Philippines",
                   "China",
                   "North\nKorea"),
     at = 1:6, lwd = 0, cex.axis = .7)
for (i in 1:nrow(summary4plot)) {
    lines(x = rep(i, 2), y = summary4plot[i, c("2.5%", "97.5%")])
}

